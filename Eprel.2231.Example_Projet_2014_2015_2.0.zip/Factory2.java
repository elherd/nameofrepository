package jeuDeRole;

public interface Factory2 {
	public Solid make(TypeObject object, MyWorld myWorld, Position position) throws ExceptionPosition;
}
