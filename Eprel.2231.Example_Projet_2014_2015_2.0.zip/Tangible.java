package jeuDeRole;

public interface Tangible {
  char showAs();
  void interactWith(Player p);
  
  
}
