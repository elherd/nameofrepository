package jeuDeRole;

public enum Direction {
	NORTH, SOUTH, WEST, EAST;

}
