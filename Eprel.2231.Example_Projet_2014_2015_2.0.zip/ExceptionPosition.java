package jeuDeRole;

public class ExceptionPosition extends Exception{
	
	public ExceptionPosition(){
	     super("this position don't exist in our world");
	}

}
