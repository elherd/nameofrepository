package jeuDeRole;

public enum TypeObject {
	player, police, civil, water, wall, soldier ;
}
